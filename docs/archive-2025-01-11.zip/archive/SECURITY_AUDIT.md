# 🔒 Security Audit & Penetration Testing Guide

**Status**: ✅ Implementiert  
**Arbeitspaket**: #5 - Security Audit & Penetration Testing  
**Version**: 1.0.0

---

## 📋 Übersicht

Dieses Dokument beschreibt das implementierte Security-Audit-System der Blockchain Forensics Platform. Das System umfasst automatisierte Security-Scans, Penetration-Tests und kontinuierliche Sicherheitsüberwachung.

---

## 🛠️ Implementierte Tools

### 1. **Bandit** - Python Security Scanner
- **Zweck**: Erkennt häufige Sicherheitsprobleme in Python-Code
- **Prüft**: 
  - SQL Injection
  - Command Injection
  - Hardcoded Passwords
  - Insecure Crypto
  - Assert Statements
- **Konfiguration**: `.bandit`
- **Ausgabe**: `security-reports/bandit.json`

### 2. **Safety** - Dependency Vulnerability Scanner
- **Zweck**: Prüft Python-Dependencies auf bekannte Schwachstellen
- **Datenbank**: CVE-basierte Vulnerability Database
- **Prüft**: 
  - Vulnerable Packages
  - Outdated Dependencies
  - Known CVEs
- **Ausgabe**: `security-reports/safety.json`

### 3. **Semgrep** - SAST (Static Application Security Testing)
- **Zweck**: Pattern-basierte Code-Analyse
- **Prüft**: 
  - OWASP Top 10 Vulnerabilities
  - Custom Security Rules
  - CWE-classified Issues
- **Konfiguration**: `.semgrep.yml`
- **Rules**: 10+ Custom Security Rules
- **Ausgabe**: `security-reports/semgrep.json`

### 4. **detect-secrets** - Secrets Detection
- **Zweck**: Findet hardcoded Secrets im Code
- **Prüft**: 
  - API Keys
  - Passwords
  - Tokens
  - Private Keys
- **Ausgabe**: `security-reports/secrets.json`

### 5. **Trivy** - Container Security Scanner
- **Zweck**: Scannt Docker-Images auf Vulnerabilities
- **Prüft**: 
  - OS Packages
  - Application Dependencies
  - Known CVEs
- **Integration**: GitHub Actions

### 6. **Custom Security Tests** - Penetration Testing
- **Zweck**: Automatisierte Security Tests
- **Tests**: 
  - SQL Injection Prevention
  - XSS Protection
  - CSRF Prevention
  - Authentication Bypass
  - Authorization Flaws
  - Session Management
- **Location**: `backend/tests/security/`

---

## 🚀 Verwendung

### Schnellstart: Vollständiges Audit

```bash
# Einfacher Run
./scripts/run-security-audit.sh

# Output: security-reports/security-audit_YYYYMMDD_HHMMSS.md
```

### Einzelne Tools ausführen

```bash
# 1. Bandit
cd backend
bandit -r app/ -f json -o ../security-reports/bandit.json

# 2. Safety
safety check --json > security-reports/safety.json

# 3. Semgrep
semgrep --config=.semgrep.yml --json backend/app/

# 4. Secrets
detect-secrets scan --all-files > security-reports/secrets.json

# 5. Security Tests
cd backend
pytest tests/security/ -v
```

### Programmatisch (Python)

```python
from backend.app.security.audit import SecurityAuditor
import asyncio

async def run_audit():
    auditor = SecurityAuditor(".")
    report = await auditor.run_full_audit()
    
    print(f"Total Issues: {report.total_issues}")
    print(f"Critical: {report.critical_issues}")
    print(f"High: {report.high_issues}")
    print(report.summary)

asyncio.run(run_audit())
```

---

## 📊 Security Report Format

### JSON Report
```json
{
  "timestamp": "2025-01-11T14:30:00",
  "scan_duration_seconds": 45.3,
  "total_files_scanned": 150,
  "total_issues": 12,
  "critical_issues": 0,
  "high_issues": 2,
  "medium_issues": 5,
  "low_issues": 5,
  "issues": [
    {
      "severity": "high",
      "category": "sql-injection",
      "title": "Potentielle SQL Injection",
      "description": "Unvalidated user input in query",
      "file": "app/api/v1/trace.py",
      "line": 123,
      "cwe": "CWE-89",
      "owasp": "A03:2021",
      "recommendation": "Use parameterized queries"
    }
  ],
  "tools_used": ["Bandit", "Safety", "Semgrep", "detect-secrets"],
  "summary": "📊 Insgesamt 12 Sicherheitsprobleme gefunden..."
}
```

### Markdown Report
```markdown
# 🔒 Security Audit Report

**Timestamp**: 2025-01-11 14:30:00
**Scan Duration**: 45.30s
**Files Scanned**: 150

## 📊 Summary
⚠️ 2 HIGH Issues (zeitnahe Behebung empfohlen)
⚡ 5 MEDIUM Issues (geplante Behebung)
...

## 🔍 Detailed Issues
### HIGH Severity (2 issues)
...
```

---

## 🔐 Semgrep Custom Rules

Implementierte Security-Rules (`.semgrep.yml`):

1. **SQL Injection Check** (CWE-89, OWASP A03)
2. **Command Injection Check** (CWE-78, OWASP A03)
3. **Hardcoded Secrets** (CWE-798, OWASP A07)
4. **Insecure Deserialization** (CWE-502, OWASP A08)
5. **Weak Cryptography (MD5)** (CWE-327, OWASP A02)
6. **Missing Authentication** (OWASP A01)
7. **SSRF Prevention** (CWE-918, OWASP A10)
8. **Path Traversal** (CWE-22, OWASP A01)
9. **Missing Rate Limiting** (OWASP A04)
10. **Insecure Random** (CWE-330, OWASP A02)

---

## 🧪 Security Tests

### Implementierte Test-Suites

#### 1. SQL Injection Tests (`test_sql_injection.py`)
```python
- test_sql_injection_in_address_param()
- test_sql_injection_in_trace_request()
- test_sql_injection_in_user_query()
- test_no_sql_error_leakage()
- test_input_validation_on_all_endpoints()
```

#### 2. Authentication Tests (`test_authentication.py`)
```python
- test_jwt_token_structure()
- test_expired_token_rejected()
- test_invalid_token_signature_rejected()
- test_missing_token_rejected()
- test_malformed_token_rejected()
- test_role_escalation_prevention()
- test_password_strength_validation()
```

#### 3. XSS & CSRF Tests (`test_xss_csrf.py`)
```python
- test_xss_in_response_escaped()
- test_csrf_token_required_for_state_change()
```

### Tests ausführen

```bash
cd backend

# Alle Security Tests
pytest tests/security/ -v

# Einzelne Test-Suite
pytest tests/security/test_sql_injection.py -v

# Mit Coverage
pytest tests/security/ --cov=app --cov-report=html
```

---

## 🔄 CI/CD Integration

### GitHub Actions Workflow

**File**: `.github/workflows/security-scan.yml`

**Trigger:**
- Push auf `main` oder `develop`
- Pull Requests
- Täglich um 3 Uhr morgens (cron)

**Jobs:**
1. **Bandit Scan** - Python Security
2. **Safety Check** - Dependencies
3. **Semgrep SAST** - Code Analysis
4. **Secrets Detection** - Hardcoded Secrets
5. **Trivy** - Container Scan
6. **Security Tests** - pytest tests/security/

**Outputs:**
- SARIF Reports → GitHub Security Tab
- Artifacts → Download from Actions

---

## 📈 Security Metrics & KPIs

### Tracking

1. **Total Issues Over Time**
   - Trend: Abnehmend ✅
   - Target: <5 High/Critical Issues

2. **Time to Fix**
   - Critical: <24h
   - High: <7 Tage
   - Medium: <30 Tage

3. **Test Coverage**
   - Security Tests: 80%+
   - Critical Paths: 100%

4. **Scan Frequency**
   - Automated: Täglich
   - Manual Audit: Monatlich
   - Penetration Test: Vierteljährlich

---

## 🎯 Severity Levels & Response

### CRITICAL (🚨)
- **Definition**: Sofort ausnutzbare Schwachstelle
- **Beispiele**: SQL Injection, RCE, Auth Bypass
- **Response**: Immediate Fix (< 24h)
- **Deployment**: Hotfix Release

### HIGH (⚠️)
- **Definition**: Schwere Sicherheitsprobleme
- **Beispiele**: XSS, CSRF, Privilege Escalation
- **Response**: Urgent Fix (< 7 Tage)
- **Deployment**: Next Release

### MEDIUM (⚡)
- **Definition**: Moderate Risiken
- **Beispiele**: Missing Rate Limit, Weak Crypto
- **Response**: Planned Fix (< 30 Tage)
- **Deployment**: Scheduled Update

### LOW (ℹ️)
- **Definition**: Geringes Risiko, Best Practice
- **Beispiele**: Information Disclosure, Weak Headers
- **Response**: Optional Fix
- **Deployment**: Next Major Version

---

## 📋 Security Checklist

### Pre-Deployment Checklist

- [ ] Security Audit durchgeführt (`./scripts/run-security-audit.sh`)
- [ ] 0 Critical Issues
- [ ] 0 High Issues (oder dokumentiert & accepted)
- [ ] Alle Security Tests bestanden
- [ ] Dependencies aktualisiert
- [ ] Secrets aus Code entfernt
- [ ] HTTPS/TLS konfiguriert
- [ ] Rate Limiting aktiviert
- [ ] CORS richtig gesetzt
- [ ] Security Headers gesetzt
- [ ] Logging aktiviert
- [ ] Backup-Strategie vorhanden

### Code Review Checklist

- [ ] Input Validation vorhanden
- [ ] Parameterized Queries verwendet
- [ ] Authentication auf geschützten Routen
- [ ] Authorization-Checks implementiert
- [ ] Keine Secrets im Code
- [ ] Error Messages nicht zu detailliert
- [ ] Logging ohne Sensitive Data
- [ ] HTTPS für externe Requests

---

## 🔧 Konfiguration

### Bandit Configuration (`.bandit`)

```ini
[bandit]
exclude_dirs = ['/tests/', '/venv/']
skips = ['B101']  # assert_used in Tests erlaubt
exclude_level = ['LOW']
output_format = 'json'
```

### Semgrep Configuration (`.semgrep.yml`)

```yaml
rules:
  - id: sql-injection-check
    severity: ERROR
    patterns:
      - pattern: cursor.execute($QUERY + $USER_INPUT)
    message: "Potentielle SQL Injection!"
```

---

## 📚 Referenzen & Standards

### Security Standards
- **OWASP Top 10 (2021)**: Alle relevanten Kategorien abgedeckt
- **CWE**: Common Weakness Enumeration
- **SANS Top 25**: Critical Software Errors
- **NIST**: Cybersecurity Framework

### Tools Documentation
- [Bandit](https://bandit.readthedocs.io/)
- [Safety](https://pyup.io/safety/)
- [Semgrep](https://semgrep.dev/docs/)
- [detect-secrets](https://github.com/Yelp/detect-secrets)
- [Trivy](https://aquasecurity.github.io/trivy/)

---

## 🚨 Incident Response

### Bei Critical Security Issue:

1. **Sofortige Maßnahmen**
   - Service stoppen (falls nötig)
   - Issue isolieren
   - Logs sichern

2. **Analyse**
   - Scope bestimmen
   - Exploit-Versuch prüfen
   - Impact bewerten

3. **Fix**
   - Patch entwickeln
   - Review durch zweiten Dev
   - Security Tests schreiben

4. **Deployment**
   - Hotfix deployen
   - Monitoring erhöhen
   - Incident dokumentieren

5. **Post-Mortem**
   - Root Cause Analysis
   - Preventive Maßnahmen
   - Team-Kommunikation

---

## 📞 Support & Kontakt

**Security Issues melden:**
- Email: security@blockchain-forensics.com
- Private: GitHub Security Advisory
- Urgent: PGP-verschlüsselt

**Security Team:**
- Security Lead: TBD
- DevSecOps: TBD
- On-Call: 24/7 für Critical Issues

---

## ✅ Fazit

Das Security-Audit-System ist vollständig implementiert und einsatzbereit. Alle Tools sind konfiguriert, Tests implementiert und CI/CD-Integration aktiv.

**Nächste Schritte:**
1. Initiales Security Audit durchführen
2. Gefundene Issues priorisieren
3. Fix-Plan erstellen
4. Monatliche Reviews etablieren
5. Penetration Testing durch externe Firma planen

---

**Version**: 1.0.0  
**Last Updated**: 2025-01-11  
**Status**: ✅ Production Ready
